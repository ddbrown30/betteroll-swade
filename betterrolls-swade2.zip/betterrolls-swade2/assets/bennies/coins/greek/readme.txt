The following files are licensed under the Creative Commons Attribution-Share Alike 2.5 Generic license
Attribution: Classical Numismatic Group, Inc. http://www.cngcoins.com

- PTOLEMAIC KINGS of EGYPT_FRONT.png
- PTOLEMAIC KINGS of EGYPT_BACK.png

