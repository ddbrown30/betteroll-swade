/// Actions for combat options in the core rulebook

const CALLED_SHOT_SELECTOR = {
  or_selector: [
    {
      and_selector: [
        {
          selector_type: "item_type",
          selector_value: "power",
        },
        {
          selector_type: "item_name",
          selector_value: "Bolt",
        },
      ]
    },
    {
      selector_type: "item_type",
      selector_value: "weapon",
    },
  ]
};

export const COMBAT_OPTIONS = [
  {
    id: "AIM",
    name: "BRSW.Aiming",
    button_name: "BRSW.Aiming",
    skillMod: 2,
    aimingIgnoreMod: 4,
    selector_type: "skill",
    selector_value: "BRSW.Shooting",
    group: "BRSW.AttackOption",
    defaultChecked: {
      selector_type: "actor_has_effect",
      selector_value: "BRSW.Aiming",
    },
  },
  {
    id: "WTK",
    name: "BRSW.WildAttack",
    button_name: "BRSW.WildAttack",
    skillMod: 2,
    dmgMod: 2,
    dmgOverride: "",
    selector_type: "skill",
    selector_value: "fighting",
    self_add_status: "vulnerable",
    group: "BRSW.AttackOption",
    defaultChecked: {
      selector_type: "actor_has_effect",
      selector_value: "BRSW.WildAttackEffect",
    },
  },
  {
    id: "DROP",
    name: "BRSW.TheDrop",
    button_name: "BRSW.TheDrop",
    skillMod: 4,
    dmgMod: 4,
    selector_type: "item_has_damage",
    selector_value: "true",
    group: "BRSW.SituationalModifiers",
  },
  {
    id: "CS-ARM",
    name: "BRSW.CalledArm",
    button_name: "BRSW.CalledArm",
    skillMod: -2,
    ...CALLED_SHOT_SELECTOR,
    change_location: "arms",
    group: "BRSW.AttackOptionCalledShot",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "CS-HAND",
    name: "BRSW.CalledHand",
    button_name: "BRSW.CalledHand",
    skillMod: -4,
    ...CALLED_SHOT_SELECTOR,
    change_location: "arms",
    group: "BRSW.AttackOptionCalledShot",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "CS-HEAD",
    name: "BRSW.CalledHead",
    button_name: "BRSW.CalledHead",
    skillMod: -4,
    dmgMod: +4,
    dmgOverride: "",
    ...CALLED_SHOT_SELECTOR,
    change_location: "head",
    group: "BRSW.AttackOptionCalledShot",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "CS-LEG",
    name: "BRSW.CalledLeg",
    button_name: "BRSW.CalledLeg",
    skillMod: -2,
    ...CALLED_SHOT_SELECTOR,
    change_location: "legs",
    group: "BRSW.AttackOptionCalledShot",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "1-LightCover",
    name: "BRSW.LightCover",
    button_name: "BRSW.LightCover",
    skillMod: "-2",
    or_selector: [
      {
        selector_type: "item_type",
        selector_value: "power",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.Cover",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "2-MediumCover",
    name: "BRSW.MediumCover",
    button_name: "BRSW.MediumCover",
    skillMod: "-4",
    or_selector: [
      {
        selector_type: "item_type",
        selector_value: "power",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.Cover",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "3-HeavyCover",
    name: "BRSW.HeavyCover",
    button_name: "BRSW.HeavyCover",
    skillMod: "-6",
    or_selector: [
      {
        selector_type: "item_type",
        selector_value: "power",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.Cover",
    group_single: true,
    aiming_ignores: true,
  },
  {
    id: "4-NearTotalCover",
    name: "BRSW.NearTotalCover",
    button_name: "BRSW.NearTotalCover",
    skillMod: "-8",
    or_selector: [
      {
        selector_type: "item_type",
        selector_value: "power",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.Cover",
    group_single: true,
    aiming_ignores: true,
  },

  {
    id: "UNSTABLEPLATFORMGM",
    name: "BRSW.UnstablePlatform",
    button_name: "BRSW.UnstablePlatform",
    skillMod: "-2",
    selector_type: "gm_action",
    group: "BRSW.SituationalModifiers",
  },

  {
    id: "1LDimGm",
    name: "BRSW.IlluminationDim",
    button_name: "BRSW.IlluminationDim",
    skillMod: "-2",
    selector_type: "gm_action",
    group: "BRSW.Illumination",
    group_single: true,
  },
  {
    id: "2LDarkGm",
    name: "BRSW.IlluminationDark",
    button_name: "BRSW.IlluminationDark",
    skillMod: "-4",
    selector_type: "gm_action",
    group: "BRSW.Illumination",
    group_single: true,
  },
  {
    id: "3LPitchGm",
    name: "BRSW.IlluminationPitch",
    button_name: "BRSW.IlluminationPitch",
    skillMod: "-6",
    selector_type: "gm_action",
    group: "BRSW.Illumination",
    group_single: true,
  },
  {
    id: "1LDim",
    name: "BRSW.IlluminationDim",
    button_name: "BRSW.IlluminationDim",
    not_selector: [
      {
        or_selector: [
          {
            selector_type: "actor_has_ability",
            selector_value: "BRSW.AbilityName-LowLightVision",
          },
          {
            selector_type: "actor_has_ability",
            selector_value: "BRSW.AbilityName-NightVision",
          },
        ],
      },
    ],
    skillMod: "-2",
    group: "BRSW.Illumination",
    group_single: true,
    defaultChecked: {
      selector_type: "gm_action_enabled",
      selector_value: "1LDimGm",
    },
  },
  {
    id: "2LDark",
    name: "BRSW.IlluminationDark",
    button_name: "BRSW.IlluminationDark",
    not_selector: [
      {
        or_selector: [
          {
            selector_type: "actor_has_ability",
            selector_value: "BRSW.AbilityName-LowLightVision",
          },
          {
            selector_type: "actor_has_ability",
            selector_value: "BRSW.AbilityName-NightVision",
          },
        ],
      },
    ],
    skillMod: "-4",
    group: "BRSW.Illumination",
    group_single: true,
    defaultChecked: {
      selector_type: "gm_action_enabled",
      selector_value: "2LDarkGm",
    },
  },
  {
    id: "3LPitch",
    name: "BRSW.IlluminationPitch",
    button_name: "BRSW.IlluminationPitch",
    not_selector: [
      {
        or_selector: [
          {
            selector_type: "actor_has_ability",
            selector_value: "BRSW.AbilityName-NightVision",
          },
        ],
      },
    ],
    skillMod: "-6",
    group: "BRSW.Illumination",
    group_single: true,
    defaultChecked: {
      selector_type: "gm_action_enabled",
      selector_value: "3LPitchGm",
    },
  },
  {
    id: "UNSTABLEPLATFORM",
    name: "BRSW.UnstablePlatform",
    button_name: "BRSW.UnstablePlatform",
    skillMod: "-2",
    and_selector: [
      {
        or_selector: [
          { selector_type: "skill", selector_value: "Shooting" },
          {
            selector_type: "skill",
            selector_value: "Athletics",
          },
        ],
      },
      {
        not_selector: [
          {
            selector_type: "actor_has_edge",
            selector_value: "BRSW.EdgeName-Steady-Hands",
          },
        ],
      },
    ],
    group: "BRSW.SituationalModifiers",
    defaultChecked: {
      selector_type: "gm_action_enabled",
      selector_value: "UNSTABLEPLATFORMGM",
    },
  },
  {
    id: "TOUCHATTACK",
    name: "BRSW.TouchAttack",
    button_name: "BRSW.TouchAttack",
    skillMod: "+2",
    dmgOverride: "0",
    selector_type: "skill",
    selector_value: "fighting",
    group: "BRSW.SituationalModifiers",
  },
  {
    id: "NONLETHALDAMAGE",
    name: "BRSW.NonlethalDamage",
    button_name: "BRSW.NonlethalDamage",
    skillMod: "-1",
    selector_type: "skill",
    selector_value: "fighting",
    group: "BRSW.SituationalModifiers",
  },
  {
    id: "RAN",
    name: "BRSW.Ran",
    button_name: "BRSW.Ran",
    skillMod: "-2",
    not_selector: [
      {
        selector_type: "actor_has_edge",
        selector_value: "BRSW.EdgeName-Steady-Hands",
      },
    ],
    group: "BRSW.SituationalModifiers",
  },
  {
    id: "2ACTIONS",
    name: "BRSW.Two-actions",
    button_name: "BRSW.Two-actions",
    skillMod: "-2",
    selector_type: "all",
    group: "BRSW.Multi-action",
    group_single: true,
  },
  {
    id: "3ACTIONS",
    name: "BRSW.Three-actions",
    button_name: "BRSW.Three-actions",
    skillMod: "-4",
    selector_type: "all",
    group: "BRSW.Multi-action",
    group_single: true,
  },
  {
    id: "GROUP_ROLL",
    name: "BRSW.GroupRoll",
    button_name: "BRSW.GroupRoll",
    add_wild_die: "true",
    selector_type: "is_wildcard",
    selector_value: "false",
    group: "BRSW.SituationalModifiers",
  },
  {
    id: "AttackInanimateObject ",
    name: "BRSW.AttackInanimate",
    button_name: "BRSW.AttackInanimate",
    avoid_exploding_damage: "true",
    or_selector: [
      { selector_type: "item_type", selector_value: "power" },
      { selector_type: "item_type", selector_value: "weapon" },
    ],
    group: "BRSW.AttackOption",
  },
  {
    id: "DESPERATE_ATTACK-2",
    name: "Desperate Attack +2",
    button_name: "Desperate Attack +2",
    skillMod: 2,
    dmgMod: -2,
    dmgOverride: "",
    and_selector: [
      {
        selector_type: "skill",
        selector_value: "fighting",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.AttackOptionDesperate",
    group_single: true,
  },
  {
    id: "DESPERATE_ATTACK-4",
    name: "Desperate Attack +4",
    button_name: "Desperate Attack +4",
    skillMod: 4,
    dmgMod: -4,
    dmgOverride: "",
    and_selector: [
      {
        selector_type: "skill",
        selector_value: "fighting",
      },
      {
        selector_type: "item_type",
        selector_value: "weapon",
      },
    ],
    group: "BRSW.AttackOptionDesperate",
    group_single: true,
  },
];
